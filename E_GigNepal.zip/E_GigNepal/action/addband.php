<?php

include("../database/db_conn.php");	//a step back to access the file 'db_conn.php'
	if(isset($_POST['Add'])){
		$bandname=$_POST['bandname'];
		$genre=$_POST['bandgenre'];
		$desc=$_POST['banddescription'];
		$target= "img/".basename($_FILES['upload']['name']);
		$file=$_FILES['upload']['name'];
		$user=$_POST['user'];
		
		
		$query="insert into band(band_id,band_name,genre,description,photo,added_by) values(NULL,'$bandname','$genre','$desc','$file','$user')";
		
		if(move_uploaded_file($_FILES['upload']['tmp_name'], $target)){
		if (mysqli_query($conn,$query)){
					//$last_id= mysql_insert_id($conn);
					echo "<script> alert('New band added succesfully'); window.location.href='../user_dashboard.php'; </script>";
		}
		else{
			echo "<script> alert('Cannot add duplicate use of band name'); window.location.href='../user_dashboard.php'; </script>";
		}
		}
		else{
			echo "<script> alert('Cannot add image'); window.location.href='../user_dashboard.php'; </script>";
		}
		mysqli_close($conn);
	}
	

?>