<?php
	session_start();
	include("../database/db_conn.php");	//a step back to access the file 'db_conn.php'
	if(isset($_POST['btn_login'])){
		$un=$_POST['uname'];
		$pw=$_POST['psw'];
		$encpw=md5($pw);
		$query="select * from user where username='$un' and password='$encpw'";
		$result=mysqli_query($conn,$query);
		$num=mysqli_num_rows($result);	//counts no. of rows
		
		if($num>0){
			$_SESSION['login']="OK";	//session is set in successful login
			$_SESSION['username']="$un";
			//header("location:../user_dashboard.php");	//redirects a step back to 'userdashboard.php'
			echo "<script> alert('Welcome!!!". " ".$_SESSION['username'] ." "."You are logged in...'); window.location.href='../user_dashboard.php'; </script>";
		}else{
			echo "<script> alert('Either Username or Password is incorrect'); window.location.href='../index.php'; </script>";
			//header("location:../index.php"); //redirects a step back to 'index.php'
		}
	}
?>

