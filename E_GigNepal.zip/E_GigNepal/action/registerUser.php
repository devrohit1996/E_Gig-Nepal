<?php
	include("../database/db_conn.php");	//a step back to access the file 'db_conn.php'
	if(isset($_POST['btn_register'])){
		$un=$_POST['uname'];
		$fn=$_POST['fname'];
		$pw=$_POST['psw'];
		$rpw=$_POST['rpsw'];
		$add=$_POST['add'];
		$gender= $_POST['gender'];
		$con=$_POST['cnum'];
		$em=$_POST['email'];
		$col=$_POST['security'];
		$encpass=md5($pw);
		
		if ($pw==$rpw){
		$query="insert into user(user_id,username,full_name,password,address,gender,contact_no,email,security_ques) values(NULL,'$un','$fn','$encpass','$add','$gender','$con','$em','$col')";
		
		if (mysqli_query($conn,$query)){
					//$last_id= mysql_insert_id($conn);
					echo "<script> alert('Registered succesfully'); window.location.href='../index.php'; </script>";
		}
		else{
			echo "<script> alert('Cannot register duplicate use of username'); window.location.href='../index.php'; </script>";
		}
		
		mysqli_close($conn);
	}
	else{
		echo "<script> alert('Cannot register passwords does not match'); window.location.href='../index.php'; </script>";
	}
	}
?>