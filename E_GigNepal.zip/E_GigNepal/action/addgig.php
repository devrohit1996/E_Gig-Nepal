<?php

include("../database/db_conn.php");	//a step back to access the file 'db_conn.php'
	if(isset($_POST['Add'])){
		$gigname=$_POST['gigname'];
		$desc=$_POST['description'];
		$date=$_POST['date'];
		$venue=$_POST['venue'];
		$contct=$_POST['contact'];
		$target= "img/".basename($_FILES['upload']['name']); 
		$user=$_POST['user'];
		$photo=$_FILES['upload']['name'];
		
		$query="insert into gig(gig_id,gig_name,gig_details,date,venue,contact_links,photo,added_by) values(NULL,'$gigname','$desc','$date','$venue','$contct','$photo','$user')";
		
		if(move_uploaded_file($_FILES['upload']['tmp_name'], $target)){
		if (mysqli_query($conn,$query)){
					//$last_id= mysql_insert_id($conn);
					echo "<script> alert('Gig added succesfully'); window.location.href='../user_dashboard.php'; </script>";
		}
		else{
			echo "<script> alert('Cannot add duplicate use of gig name'); window.location.href='../user_dashboard.php'; </script>";
		}
	}
	else{
		echo "<script> alert('Please add image'); window.location.href='../user_dashboard.php'; </script>";
	}
		
		mysqli_close($conn);
	}
	

?>