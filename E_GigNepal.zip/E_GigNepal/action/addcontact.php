<?php
	include("../database/db_conn.php");	//a step back to access the file 'db_conn.php'
	if(isset($_POST['send'])){
		$name=$_POST['name'];
		$email=$_POST['email'];
		$subject=$_POST['subject'];
		$message=$_POST['message'];
		$date=date("F j, Y, g:i a");
		
		$query="insert into contact(cntct_id,name,email,subject,message,date) values(NULL,'$name','$email','$subject','$message','$date')";
		
		if (mysqli_query($conn,$query)){
					//$last_id= mysql_insert_id($conn);
					echo "<script> alert('Message sent succesfully'); window.location.href='../user_dashboard.php'; </script>";
		}
		else{
			echo "<script> alert('Cannot send message'); window.location.href='../user_dashboard.php'; </script>";
		}
		
		mysqli_close($conn);
	}
	
	
?>