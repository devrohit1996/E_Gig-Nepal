<?php
	session_start();
	echo "<script> alert('You are logging out...'); window.location.href='../index.php'; </script>";
	session_destroy();//destroys the session
?>