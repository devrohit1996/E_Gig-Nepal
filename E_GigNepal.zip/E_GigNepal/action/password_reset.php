<?Php
	
	include("../database/db_conn.php");	//a step back to access the file 'db_conn.php'
	if(isset($_POST['reset'])){
		$user=$_POST['username'];
		$ans=$_POST['security'];		
		$pw=$_POST['pw'];
		$npw=$_POST['npw'];



		if($pw==$npw){

		$encpw=md5($pw);
	
		$sql = "UPDATE user SET password='$encpw' WHERE username='$user' and security_ques='$ans'";
			if(mysqli_query($conn, $sql)){
				echo " <script> alert('Password Changed succesfully.'); window.location.href='../index.php'; </script> ";
			}
			else{
				echo " <script> alert('Security answer or username not correct! Re-try'); window.location.href='../index.php'; </script> ";
			}
		}
		else{

			echo "<script> alert('Passwords do not match! Re-try'); window.location.href='../index.php'; </script> ";
		}

	}
	mysqli_close($conn);
	
?>