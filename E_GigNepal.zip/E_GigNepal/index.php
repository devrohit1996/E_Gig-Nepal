<?php
  include("database/db_conn.php"); 

  //header 
  $id='1';
  $queryh=$conn->prepare("select * from header where id='$id'");
  $queryh->execute();
  $resulth= $queryh->get_result();
    $row= $resulth->fetch_array(MYSQLI_ASSOC);   
    $ht1= $row['header_tag1'];
    $ht2= $row['header_tag2'];
    $ht3= $row['header_tag3'];
    $vdo= $row['bg_video'];

  //about 
  $querya=$conn->prepare("select * from about_us where id='$id'");
  $querya->execute();
  $resulta= $querya->get_result();
    $row= $resulta->fetch_array(MYSQLI_ASSOC);
    $desc= $row['description'];

  //parallx 1
  $queryp1=$conn->prepare("select * from parallax1 where id='$id'");
  $queryp1->execute();
  $resultp1= $queryp1->get_result();
    $row= $resultp1->fetch_array(MYSQLI_ASSOC);
    $p1txt= $row['text'];    

  //parallx2
  $queryp2=$conn->prepare("select * from parallax2 where id='$id'");
  $queryp2->execute();
  $resultp2= $queryp2->get_result();
    $row= $resultp2->fetch_array(MYSQLI_ASSOC);
    $p2txt1= $row['text1'];
    $p2name1= $row['name1'];
    $p2com1= $row['company1'];
    $p2txt2= $row['text2'];
    $p2name2= $row['name2'];
    $p2com2= $row['company2'];   

  //links 
  $querysm=$conn->prepare("select * from social_media where id='$id'");
  $querysm->execute();
  $resultsm= $querysm->get_result();
    $row= $resultsm->fetch_array(MYSQLI_ASSOC);
    $fb= $row['facebook'];
    $gp= $row['googleplus'];
    $ig= $row['instagram'];    
 
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>E-Gig Nepal</title>
	
    <!-- css -->
    <link rel="icon" href="img/icon.png" type="image/png">
    <link href="css/bootstrap.min.css" rel="stylesheet" type="text/css">
    <link href="font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
	<link href="css/nivo-lightbox.css" rel="stylesheet" />
	<link href="css/nivo-lightbox-theme/default/default.css" rel="stylesheet" type="text/css" />
	<link href="css/owl.carousel.css" rel="stylesheet" media="screen" />
    <link href="css/owl.theme.css" rel="stylesheet" media="screen" />
	<link href="css/flexslider.css" rel="stylesheet" />
	<link href="css/animate.css" rel="stylesheet" />
    <link href="css/style.css" rel="stylesheet">
	<link href="color/default.css" rel="stylesheet">
    
    <!-- =======================================================
        Theme Name: Valera
        Theme URL: https://bootstrapmade.com/valera-free-bootstrap-theme/
        Author: BootstrapMade
        Author URL: https://bootstrapmade.com
    ======================================================= -->

</head>

<body id="page-top" data-spy="scroll" data-target=".navbar-custom">

    <!-- page loader -->
    <div id="page-loader">
      <div class="loader">
        <div class="spinner">
          <div class="spinner-container con1">
            <div class="circle1"></div>
            <div class="circle2"></div>
            <div class="circle3"></div>
            <div class="circle4"></div>
          </div>
          <div class="spinner-container con2">
            <div class="circle1"></div>
            <div class="circle2"></div>
            <div class="circle3"></div>
            <div class="circle4"></div>
          </div>
          <div class="spinner-container con3">
            <div class="circle1"></div>
            <div class="circle2"></div>
            <div class="circle3"></div>
            <div class="circle4"></div>
          </div>
        </div>
      </div>
    </div>
    <!-- /page loader -->

	<!-- Section: home video -->
    <section id="intro" class="home-video text-light">
		<div class="home-video-wrapper">

<div class="homevideo-container">
           <div id="P1" class="bg-player" style="display:block; margin: auto; background: rgba(0,0,0,0.5)" data-property="{videoURL:'<?php echo $vdo; ?>',containment:'.homevideo-container', quality: 'hd720', showControls: false, autoPlay:true, mute:true, startAt:0, opacity:1}"></div>
    </div>
    <div class="overlay">
      <div class="text-center video-caption">
        <div class="wow bounceInDown" data-wow-offset="0" data-wow-delay="0.8s">
          <h1 class="big-heading font-light"><span id="js-rotating"> <?php echo $ht1; ?>,<?php echo $ht2; ?>, <?php echo $ht3; ?> </span></h1>
    
		
           
				</div>
				<div class="wow bounceInUp" data-wow-offset="0" data-wow-delay="1s">
					<div class="margintop-30">
						<a href="#about" class="btn btn-skin" id="btn-scroll">Let's Rock</a>
					</div>
				</div>
			</div>
		</div>
		</div>
    </section>
	<!-- /Section: intro -->
	
	
    <!-- Navigation -->
    <div id="navigation">
        <nav class="navbar navbar-custom" role="navigation">
                              <div class="container">
                                    <div class="row">
                                          <div class="col-md-2 mob-logo">
                                                <div class="row">
                                                      <div class="site-logo">
                                                            <a href="index.html"><img src="img/logo-dark.png" alt="" /></a>
                                                      </div>
                                                </div>
                                          </div>
                                          

                                          <div class="col-md-10 mob-menu">
                                                <div class="row">
                                                      <!-- Brand and toggle get grouped for better mobile display -->
                                          <div class="navbar-header">
                                                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#menu">
                                                <i class="fa fa-bars"></i>
                                                </button>
                                          </div>
                                                      <!-- Collect the nav links, forms, and other content for toggling -->
                                                      <div class="collapse navbar-collapse" id="menu">
                                                            <ul class="nav navbar-nav navbar-right">
                                                                  <li class="active"><a href="#intro">Home</a></li>
                                                                  <li><a href="#about">About Us</a></li>
																   <li><a href="#service">Log In</a></li>
                                                                  <li><a href="#works">Registration</a></li>				                                                                  
                                                                  
                                                                  <li><a href="#contact">Contact</a></li>
																  
                                                                        </ul>
                                                                  </li>
                                                            </ul>
                                                      </div>
                                                      <!-- /.Navbar-collapse -->
                                                </div>
                                          </div>
                                    </div>
                              </div>
                              <!-- /.container -->
                        </nav>
    </div> 
    <!-- /Navigation -->  

	<!-- Section: about -->
    <section id="about" class="home-section color-dark bg-white">
		<div class="container marginbot-50">
			<div class="row">
				<div class="col-lg-8 col-lg-offset-2">
					<div class="wow flipInY" data-wow-offset="0" data-wow-delay="0.4s">
					<div class="section-heading text-center">
					<h2 class="h-bold">About</h2>
					<div class="divider-header"></div>
					<p> <?php echo $desc; ?> </p>
					</div>
					</div>
				</div>
			</div>

		</div>
		
		<div class="text-center">
		<div class="container">

		
        <div class="row">
            <div class="col-xs-6 col-sm-3 col-md-3">				
				<div class="team-wrapper-big wow bounceInUp" data-wow-delay="0.2s">
                        <div class="team-wrapper-overlay">
                          <h5> Rohit Sai </h5>
                          <p> The CEO </p>
                          <div class="social-icons">
								<ul class="team-social">
									<li class="social-facebook"><a href="#"><i class="fa fa-facebook"></i></a></li>
									<li class="social-twitter"><a href="#"><i class="fa fa-twitter"></i></a></li>
									<li class="social-google"><a href="#"><i class="fa fa-google-plus"></i></a></li>
								</ul>
                          </div>
                        </div>
                        <img src="img/team/team-leader-2.jpg" alt="" />
                </div>
            </div>
			
			<div class="col-xs-6 col-sm-3 col-md-3">
				<div class="team-wrapper-big wow bounceInUp" data-wow-delay="0.5s">
                        <div class="team-wrapper-overlay">
                          <h5> Roozan Shrestha </h5>
                          <p> The Marketing Manager </p>
                          <div class="social-icons">
								<ul class="team-social">
									<li class="social-facebook"><a href="#"><i class="fa fa-facebook"></i></a></li>
									<li class="social-twitter"><a href="#"><i class="fa fa-twitter"></i></a></li>
									<li class="social-google"><a href="#"><i class="fa fa-google-plus"></i></a></li>
								</ul>
                          </div>
                        </div>
                        <img src="img/team/team-leader-3.jpg" alt="" />
                </div>
            </div>
			<div class="col-xs-6 col-sm-3 col-md-3">
				<div class="team-wrapper-big wow bounceInUp" data-wow-delay="0.8s">
                        <div class="team-wrapper-overlay">
                          <h5> Lizan Pradhanang </h5>
                          <p> The Executive Manager </p>
                          <div class="social-icons">
								<ul class="team-social">
									<li class="social-facebook"><a href="#"><i class="fa fa-facebook"></i></a></li>
									<li class="social-twitter"><a href="#"><i class="fa fa-twitter"></i></a></li>
									<li class="social-google"><a href="#"><i class="fa fa-google-plus"></i></a></li>
								</ul>
                          </div>
                        </div>
                        <img src="img/team/team-leader-1.jpg" alt="" />
                </div>
            </div>
			<div class="col-xs-6 col-sm-3 col-md-3">
				<div class="team-wrapper-big wow bounceInUp" data-wow-delay="1s">
                        <div class="team-wrapper-overlay">
                          <h5> Salisha Pradhan </h5>
                          <p> The Director </p>
                          <div class="social-icons">
								<ul class="team-social">
									<li class="social-facebook"><a href="#"><i class="fa fa-facebook"></i></a></li>
									<li class="social-twitter"><a href="#"><i class="fa fa-twitter"></i></a></li>
									<li class="social-google"><a href="#"><i class="fa fa-google-plus"></i></a></li>
								</ul>
                          </div>
                        </div>
                        <img src="img/team/team-leader-pic3.jpg" alt="" />
                </div>
            </div>
        </div>		
		</div>
		</div>
	</section>
	<!-- /Section: about -->
	
	<!-- Section: parallax 1 -->	
	<section id="parallax1" class="home-section parallax text-light" data-stellar-background-ratio="0.5">	
           <div class="container">
				<div class="row">
					<div class="col-md-12">
						<div class="text-center">
						<h2 class="big-heading highlight-dark wow bounceInDown" data-wow-delay="0.2s"> <?php echo $p1txt; ?> </h2>
						</div>
					</div>				
				</div>
            </div>
	</section>	
	
	<!-- Section: services -->
    <section id="service" class="home-section color-dark bg-white">
		<div class="container marginbot-50">
			<div class="row">
				<div class="col-lg-8 col-lg-offset-2">
					<div class="wow flipInY" data-wow-offset="0" data-wow-delay="0.4s">
					<div class="section-heading text-center">
					<h2 class="h-bold">Log In</h2>
					<div class="divider-header"></div>
					<p>Log in the site using the form below.</p>
					</div>
					</div>
				</div>
			</div>

		</div>
				
		<div class="transbox" style="margin-left: 0px">

<form action="action/login.php" method="post">

  <div class="container">
    <label><b>Username</b></label>
    <input type="text" placeholder="Enter Username" name="uname" required style="width: 100%;
    padding: 5px 5px;
    margin: 3px 0;
    display: inline-block;
    border: 1px solid #ccc;
    box-sizing: border-box;">
  
      <label><b>Password</b></label>
    <input type="password" placeholder="Enter Password" name="psw" required style="width: 100%;
    padding: 5px 5px;
    margin: 3px 0;
    display: inline-block;
    border: 1px solid #ccc;
    box-sizing: border-box;">
        
    <button type="submit" name="btn_login" class="loginpass" style=" background-color: #4CAF50;
    color: white;
    padding: 5px 5px;
    margin: 5px 0;
    border: none;
    cursor: pointer;
    width: 100%">Login</button>
  </div>

  <div class="container">
    <span id="cancel"> <button type="button" class="cancelbtn" style=" background-color: #D70003;
    color: white;
    padding: 5px 5px;
    margin: 5px 0;
    border: none;
    cursor: pointer;
    width: 30%">Cancel</button> </span>
    <span class="fpsw"> <a href="password_reset/index.php"> Forgot password? </a> </span>
  </div>
</form>
            
</div>
	</section>
	<!-- /Section: services -->
	
	<!-- Section: parallax 2 -->	
	<section id="parallax2" class="home-section parallax text-light" data-stellar-background-ratio="0.5">  
           <div class="container" style="padding-left: 350px;">
        
         <?php
                    include("database/db_conn.php");  
   // Check connection

  $sql="SELECT * FROM user";

if ($result=mysqli_query($conn,$sql))
  {
  // Return the number of rows in result set
  $rowcount_usr=mysqli_num_rows($result);

  // Free result set
  mysqli_free_result($result);
  }


?>
          <div class="col-md-3">
            <div class="align-center color-white txt-shadow">
              <div class="icon">
                <i class="pe-7s-music pe-5x"></i>
              </div>
            <strong id="counter-music" class="number"> <?php echo $rowcount_usr; ?> </strong><br />
            <span class="text">Users</span>
            </div>
          </div>

    <?php
                    include("database/db_conn.php");  
   // Check connection

  $sql="SELECT * FROM gig";

if ($result=mysqli_query($conn,$sql))
  {
  // Return the number of rows in result set
  $rowcount_gig=mysqli_num_rows($result);

  // Free result set
  mysqli_free_result($result);
  }


?>

          <div class="col-md-3">
            <div class="align-center color-white txt-shadow">
              <div class="icon">
                <i class="pe-7s-coffee pe-5x"></i>
              </div>
            <strong id="counter-clock" class="number"> <?php echo $rowcount_gig; ?> </strong><br />
            <span class="text">Gigs</span>
            </div>
          </div>


    <?php
                    include("database/db_conn.php");  
   // Check connection

  $sql="SELECT * FROM band";

if ($result=mysqli_query($conn,$sql))
  {
  // Return the number of rows in result set
  $rowcount_band=mysqli_num_rows($result);

  // Free result set
  mysqli_free_result($result);
  }


?>

          <div class="col-md-3">
            <div class="align-center color-white txt-shadow">
              <div class="icon">
                <i class="pe-7s-cup pe-5x"></i>
              </div>
            <strong id="counter-heart" class="number"> <?php echo $rowcount_band; ?> </strong><br />
            <span class="text">Bands</span>
            </div>
          </div>
        </div>
            </div>
  </section>  
	

	<!-- Section: works -->
    <section id="works" class="home-section color-dark text-center bg-white">
		<div class="container marginbot-50">
			<div class="row">
				<div class="col-lg-8 col-lg-offset-2">
					<div class="wow flipInY" data-wow-offset="0" data-wow-delay="0.4s">
					<div class="section-heading text-center">
					<h2 class="h-bold">Registration</h2>
					<div class="divider-header"></div>
					<p>Register Here...</p>
					</div>
					</div>
				</div>
			</div>

		</div>


<div>
    <form action="action/registerUser.php" method="post" style="margin:0; padding-top:0px">

  <div class="container" style="margin-top:18px; padding-top:0px">
    <label><b>Username</b></label> <label><b>Full Name</b></label><br>
    <input type="text" placeholder="Enter Username" name="uname" required> <input type="text" placeholder="Enter name" name="fname" required> <br> <br>

    <label><b> Enter Password</b></label>    <label><b>Re - Password</b></label> <br>
    <input type="password" placeholder="Enter Password" name="psw" required>   
    <input type="password" placeholder="Re - Enter Password" name="rpsw" required> <br>
    
    <label><b>Address</b></label><br>
    <input type="text" placeholder="Enter Address" name="add" required><br>

     <label><b> Gender  </b></label><br>
    
    <select name="gender">
     <option value="Male"> Male </option>
     <option value="Female"> Female </option>
        </select> <br>
    
    <label><b>Contact</b></label>   <label><b>E-mail</b></label><br>
    <input type="text" placeholder="+977-9813816712" name="cnum" required>  
    
    <input type="email" placeholder="abc@abc.com" name="email" required> <br>
    
    <label><b>Which is your favourite color </b></label><br>
    <input type="text" placeholder="Security Question" name="security" required> <br>
        
  <button type="submit" name="btn_register" class="registerpass" style=" background-color: #4CAF50;
    color: white;
    padding: 5px 5px;
    margin: 5px 0;
    border: none;
    cursor: pointer;
    width: 30%">Register</button> <br>
    <span id="btn_cancelreg"> <button type="button" class="btn_cancel" style=" background-color: #D70003;
    color: white;
    padding: 5px 5px;
    margin: 5px 0;
    border: none;
    cursor: pointer;
    width: 30%">Cancel</button> </span>
  </div>

</form>
		

	</section>
	<!-- /Section: works -->

	<!-- Section: parallax 3 -->	
	<section id="parallax3" class="home-section parallax text-light text-center" data-stellar-background-ratio="0.5">	
           <div class="container">
				<div class="row">
					<div class="col-md-12">
						<div class="testimonialslide clearfix flexslider">
							<ul class="slides">
								<li><blockquote>
							<?php	echo $p2txt1; ?>									</blockquote>
									<h4> <?php echo $p2name1; ?> <span>&#8213; <?php echo $p2com1; ?> </span></h4> 
								</li>
								<li><blockquote>
								<?php echo $p2txt2; ?> 
									</blockquote>
									<h4> <?php echo $p2name2; ?> <span>&#8213; <?php echo $p2com2; ?> </span></h4>
								</li>	
							</ul>
						</div>					
					</div>	
				</div>
            </div>
	</section>	
	

	<!-- Section: contact -->
    <section id="contact" class="home-section nopadd-bot color-dark bg-white text-center">
		<div class="container marginbot-50">
			<div class="row">
				<div class="col-lg-8 col-lg-offset-2">
					<div class="wow flipInY" data-wow-offset="0" data-wow-delay="0.4s">
					<div class="section-heading text-center">
					<h2 class="h-bold">Contact us</h2>
					<div class="divider-header"></div>
					<p>Fill the form below to send feedbacks...</p>
					</div>
					</div>
				</div>
			</div>

		</div>
		
		<div class="container">

			<div class="row marginbot-80">
				<div class="col-md-8 col-md-offset-2">
				    <div id="sendmessage">Your message has been sent. Thank you!</div>
                    <div id="errormessage"></div>
                    <form action="action/addcontact.php" method="post" role="form" class="contactForm">
                        <div class="form-group">
                            <input type="text" name="name" class="form-control" id="name" placeholder="Your Name" data-rule="minlen:4" data-msg="Please enter at least 4 chars" />
                            <div class="validation"></div>
                        </div>
                        <div class="form-group">
                            <input type="email" class="form-control" name="email" id="email" placeholder="Your Email" data-rule="email" data-msg="Please enter a valid email" />
                            <div class="validation"></div>
                        </div>
                        <div class="form-group">
                            <input type="text" class="form-control" name="subject" id="subject" placeholder="Subject" data-rule="minlen:4" data-msg="Please enter at least 8 chars of subject" />
                            <div class="validation"></div>
                        </div>
                        <div class="form-group">
                            <textarea class="form-control" name="message" rows="5" data-rule="required" data-msg="Please write something for us" placeholder="Message"></textarea>
                            <div class="validation"></div>
                        </div>
                        
                        <div class="text-center"><button type="submit" class="btn btn-skin btn-lg btn-block" name="send">Send Message</button></div>
                    </form>
				</div>
			</div>	

			

		</div>
	</section>
	<!-- /Section: contact -->



	

	<footer>
		<div class="container">
			<div class="row">
				<div class="col-md-6 col-md-offset-3">
					
					<div class="text-center">
						<a href="#intro" class="totop"><i class="pe-7s-angle-up pe-3x"></i></a>
						
						<div class="social-widget">
							
							
							<ul class="team-social">
									<li class="social-facebook"><a href=" <?php echo $fb; ?> " target="_blank"><i class="fa fa-facebook"></i></a></li>
									<li class="social-google"><a href="<?php echo $gp; ?>" target="_blank"><i class="fa fa-google-plus"></i></a></li>
									<li class="social-instagram"><a href="<?php echo $ig; ?>" target="_blank"><i class="fa fa-instagram"></i></a></li>
							</ul>						
						
						</div>
						<p>&copy;E-Gig Nepal. All Rights Reserved</p>
                        <div class="credits">
                            
                            <a href="https://facebook.com/rohit.sai3" target="_blank">Designer Rohit Sai</a> 
                            <a href="Help/index.html" target="_blank"> Help for User </a> | <a href="Help/admin" target="_blank"> Help for Admin </a>
                        </div>
					</div>
				</div>
			</div>	
		</div>
	</footer>

    <!-- Core JavaScript Files -->
    <script src="js/jquery.min.js"></script>	 
    <script src="js/bootstrap.min.js"></script>
	<script src="https://maps.google.com/maps/api/js?sensor=false"></script>
	<script src="js/jquery.sticky.js"></script>
	<script src="js/slippry.min.js"></script> 
	<script src="js/jquery.flexslider-min.js"></script>
	<script src="js/morphext.min.js"></script>
	<script src="js/gmap.js"></script>
	<script src="js/jquery.mb.YTPlayer.js"></script>
    <script src="js/jquery.easing.min.js"></script>	
	<script src="js/jquery.scrollTo.js"></script>
	<script src="js/jquery.appear.js"></script>
	<script src="js/stellar.js"></script>
	<script src="js/wow.min.js"></script>
	<script src="js/owl.carousel.min.js"></script>
	<script src="js/nivo-lightbox.min.js"></script>
	<script src="js/jquery.nicescroll.min.js"></script>
    <script src="js/custom.js"></script>
    <script src="contactform/contactform.js"></script>
    
</body>

</html>
