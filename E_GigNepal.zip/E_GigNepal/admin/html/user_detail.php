<?php
    session_start();
    ini_set('display_errors',0);
    error_reporting('E_ALL');
    //print_r($_SESSION);
    include("../../database/db_conn.php");    
    //include("actions/searchPet.php");
    $uname=$_SESSION['username']; 
    $queryn=$conn->prepare("select * from admin where username='$uname'");
    $queryn->execute();
    $result= $queryn->get_result();
        $row= $result->fetch_array(MYSQLI_ASSOC);    
        $username= $row['Username'];
        $fname= $row['full_name'];
        $password = $row['Password'];
        $photo= $row['photo'];
    if(!isset($_SESSION['login'])){ //if session is not set
    header("location:../index.php");
    }
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" type="image/png" sizes="16x16" href="../plugins/images/icon.png">
    <title>E-GIG NEPAL | ADMIN</title>
    <!-- Bootstrap Core CSS -->
    <link href="bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Menu CSS -->
    <link href="../plugins/bower_components/sidebar-nav/dist/sidebar-nav.min.css" rel="stylesheet">
    <!-- toast CSS -->
    <link href="../plugins/bower_components/toast-master/css/jquery.toast.css" rel="stylesheet">
    <!-- morris CSS -->
    <link href="../plugins/bower_components/morrisjs/morris.css" rel="stylesheet">
    <!-- animation CSS -->
    <link href="css/animate.css" rel="stylesheet">
    <!-- Custom CSS -->
    <link href="css/style.css" rel="stylesheet">
    <!-- color CSS -->
    <link href="css/colors/blue-dark.css" id="theme" rel="stylesheet">
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
<![endif]-->
</head>

<body>
    <!-- Preloader -->
    <div class="preloader">
        <div class="cssload-speeding-wheel"></div>
    </div>
    <div id="wrapper">
        <!-- Navigation -->
        <nav class="navbar navbar-default navbar-static-top m-b-0">
            <div class="navbar-header"> <a class="navbar-toggle hidden-sm hidden-md hidden-lg " href="javascript:void(0)" data-toggle="collapse" data-target=".navbar-collapse"><i class="fa fa-bars"></i></a>
                <div class="top-left-part"><a class="logo" href="index.php"><b></b><span class="hidden-xs"><img src="../plugins/images/logo-dark.png" alt="home" /></span></a></div>
                <ul class="nav navbar-top-links navbar-left m-l-20 hidden-xs">
                    </a>
                        </form>
                    </li>
                </ul>
                <ul class="nav navbar-top-links navbar-right pull-right">
                    <li>
                        <a class="profile-pic" href="#"> <img src="../plugins/images/users/varun.jpg" alt="user-img" width="36" class="img-circle"><b class="hidden-xs"> <?php echo $username; ?> </b> </a>
                    </li>
                </ul>
            </div>
            <!-- /.navbar-header -->
            <!-- /.navbar-top-links -->
            <!-- /.navbar-static-side -->
        </nav>
        <!-- Left navbar-header -->
        <div class="navbar-default sidebar" role="navigation">
            <div class="sidebar-nav navbar-collapse slimscrollsidebar">
                <ul class="nav" id="side-menu">
                    <li style="padding: 10px 0 0;">
                        <a href="index.php" class="waves-effect"><i class="fa fa-clock-o fa-fw" aria-hidden="true"></i><span class="hide-menu">Dashboard</span></a>
                    </li>
                    <li>
                        <a href="contact_detail.php" class="waves-effect"><i class="fa fa-table fa-fw" aria-hidden="true"></i><span class="hide-menu">Contact Messages</span></a>
                    </li>
                    <li>
                        <a href="theme.php" class="waves-effect"><i class="fa fa-font fa-fw" aria-hidden="true"></i><span class="hide-menu">Theme</span></a>
                    </li>
                    <li>
                        <a href="user_detail.php" class="waves-effect"><i class="fa fa-globe fa-fw" aria-hidden="true"></i><span class="hide-menu">Users</span></a>
                    </li>
                    <li>
                        <a href="post.php" class="waves-effect"><i class="fa fa-columns fa-fw" aria-hidden="true"></i><span class="hide-menu">Posts</span></a>
                    </li>
                    <li>
                        <a href="action/adminlogout.php" class="waves-effect"><i class="fa fa-columns fa-fw" aria-hidden="true"></i><span class="hide-menu">Logout</span></a>
                    </li>
                
                </ul>
                
            </div>
        </div>
        <!-- Left navbar-header end -->
        <!-- Page Content -->
        <div id="page-wrapper">
            <div class="container-fluid">
                <div class="row bg-title">
                    <div class="col-lg-3 col-md-4 col-sm-4 col-xs-12">
                        <h4 class="page-title">User Details</h4> </div>
                    
                        <ol class="breadcrumb">
                            <li><a href="#">Dashboard| User Details </a></li>
                        </ol>
                    </div>
                    <!-- /.col-lg-12 -->
                </div>
                <!-- row -->
    
                    
                    <?php
   include("../../database/db_conn.php");  
   // Check connection

  $sqlview = "SELECT * FROM user";
                        $res = mysqli_query($conn, $sqlview) ;
                        if (mysqli_num_rows($res)>0){
                            while($row = mysqli_fetch_assoc($res)){
                            echo "<p align='justify' style='margin-bottom:5px'><b> Id:  </b> ".$row['user_id']. " | <b> Name: </b> " . $row['full_name'].  " | <b> Email: </b>" .$row['email'] . " | <b> Address: </b>" .$row['address'] . " | <b>  Gender: </b> ".$row['gender']. " | <b> User Name: </b> " . $row['username']. "<br> </p> <hr>";
                            }
                        }
                        else{
                            echo " No Users found ";
                        }   

?>

                <!-- /.row -->
                <div>
                     <h4 class="page-title">To block user permanently use the dropdown below: </h4> </div>

                    <form method="get" action="action/deleteuser.php" style="padding:10px; height:auto; width:auto">
       
        <select name='user'>  

                        <?Php
                        include("../../database/db_conn.php");  
                // Check connection
                        $sqlview = "SELECT * FROM user";
                        $res = mysqli_query($conn, $sqlview) ;
                        if (mysqli_num_rows($res)>0){
                            while($row = mysqli_fetch_assoc($res)){
           
                echo  "<option>" . $row['user_id']. "</option>";
                }
            }
          
            ?>
          </select> 
                    <input type="submit" name="block" value="Block" style="background-color: #4CAF50;
    color: white;
    padding: 5px 5px;
    margin: 5px 0;
    border: none;
    cursor: pointer;
    width: 10%">

        </form>
                

                </div>

            </div>
            <!-- /.container-fluid -->
            <footer class="footer text-center"> 2017 &copy; E-Gig Nepal Admin brought to you by egignepal.com </footer>
        </div>
        <!-- /#page-wrapper -->
    </div>
    <!-- /#wrapper -->
    <!-- jQuery -->
    <script src="../plugins/bower_components/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap Core JavaScript -->
    <script src="bootstrap/dist/js/bootstrap.min.js"></script>
    <!-- Menu Plugin JavaScript -->
    <script src="../plugins/bower_components/sidebar-nav/dist/sidebar-nav.min.js"></script>
    <!--slimscroll JavaScript -->
    <script src="js/jquery.slimscroll.js"></script>
    <!--Wave Effects -->
    <script src="js/waves.js"></script>
    <!--Counter js -->
    <script src="../plugins/bower_components/waypoints/lib/jquery.waypoints.js"></script>
    <script src="../plugins/bower_components/counterup/jquery.counterup.min.js"></script>
    <!--Morris JavaScript -->
    <script src="../plugins/bower_components/raphael/raphael-min.js"></script>
    <script src="../plugins/bower_components/morrisjs/morris.js"></script>
    <!-- Custom Theme JavaScript -->
    <script src="js/custom.min.js"></script>
    <script src="js/dashboard1.js"></script>
    

    <script src="../plugins/bower_components/toast-master/js/jquery.toast.js"></script>
    <script type="text/javascript">
    $(document).ready(function() {
        $.toast({
            heading: 'Welcome to E-GIG NEPAL admin',
            text: 'Use to edit website theme or other functions',
            position: 'top-right',
            loaderBg: '#ff6849',
            icon: 'info',
            hideAfter: 3500,
            stack: 6
        })
    });
    </script>
</body>

</html>
