<?php
include("../../../database/db_conn.php");	//a step back to access the file 'db_conn.php'
	//include("../user_dashboard.php");
	if(isset($_GET['block'])){
		$user_id=$_GET['user'];
		//$owner=$id; 

		$sql = "DELETE FROM user WHERE user_id='$user_id'";
		if(mysqli_query($conn, $sql)){
			echo " <script> alert('Blocked succesfully.'); window.location.href='../user_detail.php'; </script> ";
		}
		else{
			echo " <script> alert('Could not find user. Re-try'); window.location.href='../user_detail.php'; </script> ";
		}
	}

	mysqli_close($conn);
	
?>
