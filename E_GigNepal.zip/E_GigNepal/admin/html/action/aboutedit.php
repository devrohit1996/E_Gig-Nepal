<?php

include("../../../database/db_conn.php");

	if(isset($_GET['btn_abt'])){
		$txt=$_GET['abt'];
		$id='1';
		
		$sql = "UPDATE about_us SET description='$txt' WHERE id='$id'";
		
		if(mysqli_query($conn, $sql)){
			echo " <script> alert('Updated succesfully'); window.location.href='../theme.php'; </script> ";
		}
		else{
			echo " <script> alert('Could not update. Re-try'); window.location.href='../theme.php'; </script> ";
		}
	}

?>