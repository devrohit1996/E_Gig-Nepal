<?php
include("../../../database/db_conn.php");	//a step back to access the file 'db_conn.php'
	//include("../user_dashboard.php");
	if(isset($_GET['delete'])){
		$gig_id=$_GET['gig'];
		//$owner=$id; 

		$sql = "DELETE FROM gig WHERE gig_id='$gig_id'";
		if(mysqli_query($conn, $sql)){
			echo " <script> alert('Deleted succesfully.'); window.location.href='../post.php'; </script> ";
		}
		else{
			echo " <script> alert('Could not delete. Re-try'); window.location.href='../post.php'; </script> ";
		}
	}

	mysqli_close($conn);
	
?>
