<?php

include("../../../database/db_conn.php");

	if(isset($_GET['btn_pr1'])){
		$txt=$_GET['pr1'];
		$id='1';
		
		$sql = "UPDATE parallax1 SET text='$txt' WHERE id='$id'";
		
		if(mysqli_query($conn, $sql)){
			echo " <script> alert('Updated succesfully'); window.location.href='../theme.php'; </script> ";
		}
		else{
			echo " <script> alert('Could not update. Re-try'); window.location.href='../theme.php'; </script> ";
		}
	}

?>