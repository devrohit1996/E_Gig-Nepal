<?php

include("../../../database/db_conn.php");

  if(isset($_GET['btn_fb'])){
    $fb=$_GET['fb'];
    $id='1';
    
    $sql = "UPDATE social_media SET facebook='$fb' WHERE id='$id'";
    
    if(mysqli_query($conn, $sql)){
      echo " <script> alert('Updated succesfully'); window.location.href='../theme.php'; </script> ";
    }
    else{
      echo " <script> alert('Could not update. Re-try'); window.location.href='../theme.php'; </script> ";
    }
  }

  elseif(isset($_GET['btn_gg'])){
    $gg=$_GET['gg'];
    $id='1';
    
    $sql = "UPDATE social_media SET googleplus='$gg' WHERE id='$id'";
    
    if(mysqli_query($conn, $sql)){
      echo " <script> alert('Updated succesfully'); window.location.href='../theme.php'; </script> ";
    }
    else{
      echo " <script> alert('Could not update. Re-try'); window.location.href='../theme.php'; </script> ";
    }
  }

  elseif(isset($_GET['btn_ig'])){
    $ig=$_GET['ig'];
    $id='1';
    
    $sql = "UPDATE social_media SET instagram='$ig' WHERE id='$id'";
    
    if(mysqli_query($conn, $sql)){
      echo " <script> alert('Updated succesfully'); window.location.href='../theme.php'; </script> ";
    }
    else{
      echo " <script> alert('Could not update. Re-try'); window.location.href='../theme.php'; </script> ";
    }
  }


?>