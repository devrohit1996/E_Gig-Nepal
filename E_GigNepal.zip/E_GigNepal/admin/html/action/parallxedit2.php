<?php

include("../../../database/db_conn.php");

	if(isset($_GET['btn_mm1'])){
		$txt1=$_GET['ds1'];
		$name1=$_GET['nm1'];
		$com1=$_GET['cm1'];

		$id='1';
		
		$sql = "UPDATE parallax2 SET text1='$txt1', name1='$name1', company1='$com1' WHERE id='$id'";
		
		if(mysqli_query($conn, $sql)){
			echo " <script> alert('Updated succesfully'); window.location.href='../theme.php'; </script> ";
		}
		else{
			echo " <script> alert('Could not update. Re-try'); window.location.href='../theme.php'; </script> ";
		}
	}

	elseif(isset($_GET['btn_mm2'])){
		$txt2=$_GET['ds2'];
		$name2=$_GET['nm2'];
		$com2=$_GET['cm2'];

		$id='1';
		
		$sql = "UPDATE parallax2 SET text2='$txt2', name2='$name2', company2='$com2' WHERE id='$id'";
		
		if(mysqli_query($conn, $sql)){
			echo " <script> alert('Updated succesfully'); window.location.href='../theme.php'; </script> ";
		}
		else{
			echo " <script> alert('Could not update. Re-try'); window.location.href='../theme.php'; </script> ";
		}
	}

?>