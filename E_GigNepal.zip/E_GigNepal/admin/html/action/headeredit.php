<?php
include("../../../database/db_conn.php");

	if(isset($_GET['btn_ht1'])){
		$txt1=$_GET['ht1'];
		$id='1';
		
		
		$sql = "UPDATE header SET header_tag1='$txt1' WHERE id='$id'";
		if(mysqli_query($conn, $sql)){
			echo " <script> alert('Updated succesfully'); window.location.href='../theme.php'; </script> ";
		}
		else{
			echo " <script> alert('Could not update. Re-try'); window.location.href='../theme.php'; </script> ";
		}
	}
	elseif(isset($_GET['btn_ht2'])){
		$txt2=$_GET['ht2'];
		$id='1';
		
		
		$sql = "UPDATE header SET header_tag2='$txt2' WHERE id='$id'";
		if(mysqli_query($conn, $sql)){
			echo " <script> alert('Updated succesfully'); window.location.href='../theme.php'; </script> ";
		}
		else{
			echo " <script> alert('Could not update. Re-try'); window.location.href='../theme.php'; </script> ";
		}
	}
	elseif(isset($_GET['btn_ht3'])){
		$txt3=$_GET['ht3'];
		$id='1';
		
		
		$sql = "UPDATE header SET header_tag3='$txt3' WHERE id='$id'";
		if(mysqli_query($conn, $sql)){
			echo " <script> alert('Updated succesfully'); window.location.href='../theme.php'; </script> ";
		}
		else{
			echo " <script> alert('Could not update. Re-try'); window.location.href='../theme.php'; </script> ";
		}
	}
	elseif(isset($_GET['btn_vdo'])){
		$vdo=$_GET['vdo'];
		$id='1';
		
		
		$sql = "UPDATE header SET bg_video='$vdo' WHERE id='$id'";
		if(mysqli_query($conn, $sql)){
			echo " <script> alert('Updated succesfully'); window.location.href='../theme.php'; </script> ";
		}
		else{
			echo " <script> alert('Could not update. Re-try'); window.location.href='../theme.php'; </script> ";
		}
	}


?>