<?php
    session_start();
    ini_set('display_errors',0);
    error_reporting('E_ALL');
    //print_r($_SESSION);
    include("../../database/db_conn.php");    
    //include("actions/searchPet.php");
    $uname=$_SESSION['username']; 
    $queryn=$conn->prepare("select * from admin where username='$uname'");
    $queryn->execute();
    $result= $queryn->get_result();
        $row= $result->fetch_array(MYSQLI_ASSOC);    
        $username= $row['Username'];
        $fname= $row['full_name'];
        $password = $row['Password'];
        $photo= $row['photo'];
    if(!isset($_SESSION['login'])){ //if session is not set
    header("location:../index.php");
    }
?>

<!DOCTYPE html>
<html lang="en">

<head>


	<style type="text/css">
	

@import url(https://fonts.googleapis.com/css?family=Roboto:400,300,600,400italic);
* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
  -webkit-box-sizing: border-box;
  -moz-box-sizing: border-box;
  -webkit-font-smoothing: antialiased;
  -moz-font-smoothing: antialiased;
  -o-font-smoothing: antialiased;
  font-smoothing: antialiased;
  text-rendering: optimizeLegibility;
}

body {
  font-family: "Roboto", Helvetica, Arial, sans-serif;
  font-weight: 100;
  font-size: 12px;
  line-height: 30px;
  color: #777;
  background: #4CAF50;
}

.container {
  max-width: 400px;
  width: 100%;
  margin: 0 auto;
  position: relative;
}

#contact input[type="text"],
#contact input[type="email"],
#contact input[type="tel"],
#contact input[type="url"],
#contact textarea,
#contact button[type="submit"] {
  font: 400 12px/16px "Roboto", Helvetica, Arial, sans-serif;
}

#contact {
  background: #F9F9F9;
  padding: 20px;
  margin: 10px 0;
  box-shadow: 0 0 20px 0 rgba(0, 0, 0, 0.2), 0 5px 5px 0 rgba(0, 0, 0, 0.24);
}

#contact h3 {
  display: block;
  font-size: 30px;
  font-weight: 300;
  margin-bottom: 10px;
}

#contact h4 {
  margin: 5px 0 15px;
  display: block;
  font-size: 13px;
  font-weight: 400;
}

fieldset {
  border: medium none !important;
  margin: 0 0 10px;
  min-width: 100%;
  padding: 0;
  width: 100%;
}

#contact input[type="text"],
#contact input[type="email"],
#contact input[type="tel"],
#contact input[type="url"],
#contact textarea {
  width: 100%;
  border: 1px solid #ccc;
  background: #FFF;
  margin: 0 0 5px;
  padding: 10px;
}

#contact input[type="text"]:hover,
#contact input[type="email"]:hover,
#contact input[type="tel"]:hover,
#contact input[type="url"]:hover,
#contact textarea:hover {
  -webkit-transition: border-color 0.3s ease-in-out;
  -moz-transition: border-color 0.3s ease-in-out;
  transition: border-color 0.3s ease-in-out;
  border: 1px solid #aaa;
}

#contact textarea {
  height: 100px;
  max-width: 100%;
  resize: none;
}

#contact button[type="submit"] {
  cursor: pointer;
  width: 100%;
  border: none;
  background: #4CAF50;
  color: #FFF;
  margin: 0 0 5px;
  padding: 10px;
  font-size: 15px;
}

#contact button[type="submit"]:hover {
  background: #43A047;
  -webkit-transition: background 0.3s ease-in-out;
  -moz-transition: background 0.3s ease-in-out;
  transition: background-color 0.3s ease-in-out;
}

#contact button[type="submit"]:active {
  box-shadow: inset 0 1px 3px rgba(0, 0, 0, 0.5);
}

.copyright {
  text-align: center;
}

#contact input:focus,
#contact textarea:focus {
  outline: 0;
  border: 1px solid #aaa;
}

::-webkit-input-placeholder {
  color: #888;
}

:-moz-placeholder {
  color: #888;
}

::-moz-placeholder {
  color: #888;
}

:-ms-input-placeholder {
  color: #888;
} 

</style>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" type="image/png" sizes="16x16" href="../plugins/images/icon.png">
    <title>E-GIG NEPAL | ADMIN</title>
    <!-- Bootstrap Core CSS -->
    <link href="bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Menu CSS -->
    <link href="../plugins/bower_components/sidebar-nav/dist/sidebar-nav.min.css" rel="stylesheet">
    <!-- toast CSS -->
    <link href="../plugins/bower_components/toast-master/css/jquery.toast.css" rel="stylesheet">
    <!-- morris CSS -->
    <link href="../plugins/bower_components/morrisjs/morris.css" rel="stylesheet">
    <!-- animation CSS -->
    <link href="css/animate.css" rel="stylesheet">
    <!-- Custom CSS -->
    <link href="css/style.css" rel="stylesheet">
    <!-- color CSS -->
    <link href="css/colors/blue-dark.css" id="theme" rel="stylesheet">
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
<![endif]-->
</head>

<body>
    <!-- Preloader -->
    <div class="preloader">
        <div class="cssload-speeding-wheel"></div>
    </div>
    <div id="wrapper">
        <!-- Navigation -->
        <nav class="navbar navbar-default navbar-static-top m-b-0">
            <div class="navbar-header"> <a class="navbar-toggle hidden-sm hidden-md hidden-lg " href="javascript:void(0)" data-toggle="collapse" data-target=".navbar-collapse"><i class="fa fa-bars"></i></a>
                <div class="top-left-part"><a class="logo" href="index.php"><b></b><span class="hidden-xs"><img src="../plugins/images/logo-dark.png" alt="home" /></span></a></div>
                <ul class="nav navbar-top-links navbar-left m-l-20 hidden-xs">
                  </a>
                        </form>
                    </li>
                </ul>
                <ul class="nav navbar-top-links navbar-right pull-right">
                    <li>
                        <a class="profile-pic" href="#"> <img src="../plugins/images/users/varun.jpg" alt="user-img" width="36" class="img-circle"><b class="hidden-xs"> <?php echo $username; ?> </b> </a>
                    </li>
                </ul>
            </div>
            <!-- /.navbar-header -->
            <!-- /.navbar-top-links -->
            <!-- /.navbar-static-side -->
        </nav>
        <!-- Left navbar-header -->
        <div class="navbar-default sidebar" role="navigation">
            <div class="sidebar-nav navbar-collapse slimscrollsidebar">
                <ul class="nav" id="side-menu">
                    <li style="padding: 10px 0 0;">
                        <a href="index.php" class="waves-effect"><i class="fa fa-clock-o fa-fw" aria-hidden="true"></i><span class="hide-menu">Dashboard</span></a>
                    </li>
                    <li>
                        <a href="contact_detail.php" class="waves-effect"><i class="fa fa-table fa-fw" aria-hidden="true"></i><span class="hide-menu">Contact Messages</span></a>
                    </li>
                    <li>
                        <a href="theme.php" class="waves-effect"><i class="fa fa-font fa-fw" aria-hidden="true"></i><span class="hide-menu">Theme</span></a>
                    </li>
                    <li>
                        <a href="user_detail.php" class="waves-effect"><i class="fa fa-globe fa-fw" aria-hidden="true"></i><span class="hide-menu">Users</span></a>
                    </li>
                    <li>
                        <a href="post.php" class="waves-effect"><i class="fa fa-columns fa-fw" aria-hidden="true"></i><span class="hide-menu">Posts</span></a>
                    </li>
                    <li>
                        <a href="action/adminlogout.php" class="waves-effect"><i class="fa fa-columns fa-fw" aria-hidden="true"></i><span class="hide-menu">Logout</span></a>
                    </li>
                
                </ul>
                
            </div>
        </div>
        <!-- Left navbar-header end -->
        <!-- Page Content -->
 <div id="page-wrapper">
            <div class="container-fluid">
                <div class="row bg-title">
                    <div class="col-lg-3 col-md-4 col-sm-4 col-xs-12">
                        <h4 class="page-title">Theme</h4> </div>
                    
                        <ol class="breadcrumb">
                            <li><a href="#">Dashboard | Theme</a></li>
                        </ol>
                    </div>
                    <!-- /.col-lg-12 -->
                </div>



        <div class="container">  

  <form id="contact" action="action/headeredit.php" method="get">
    <h3>Header Theme Editor Form: </h3>
    <fieldset>
      <input placeholder="Header Tag 1" type="text" name="ht1">
    </fieldset>

    <button name="btn_ht1" type="submit" id="contact-submit" data-submit="...Sending">EDIT</button>

    <fieldset>
      <input placeholder="Header Tag 2" type="text" name="ht2">
    </fieldset>

    <button name="btn_ht2" type="submit" id="contact-submit" data-submit="...Sending">EDIT</button>

	<fieldset>
      <input placeholder="Header Tag 3" type="text" name="ht3">
    </fieldset>

    <button name="btn_ht3" type="submit" id="contact-submit" data-submit="...Sending">EDIT</button>

    <fieldset>
      <input placeholder="Background Video Youtube Link" type="text" name="vdo">
    </fieldset>

    <button name="btn_vdo" type="submit" id="contact-submit" data-submit="...Sending">EDIT</button>

  
  </form>

<hr>

<form id="contact" action="action/aboutedit.php" method="get">
    <h3>About Us Editor Form: </h3>

    <label> About Us details: </label>
    <fieldset>
      <textarea placeholder="About us tag" name="abt"> </textarea> 
    </fieldset>

    <button name="btn_abt" type="submit" id="contact-submit" data-submit="...Sending">EDIT</button>

  
  </form>

<hr>

<form id="contact" action="action/parallxedit.php" method="get">
    <h3>Parralx 1 Editor Form: </h3>
    <fieldset>
      <input placeholder="Parralx 1 text" type="text" name="pr1">
    </fieldset>

    <button name="btn_pr1" type="submit" id="contact-submit" data-submit="...Sending">EDIT</button>
  
  </form>

<hr>

<form id="contact" action="action/parallxedit2.php" method="get">
    <h3>Parralx 2 Editor Form: </h3>

    <h4> Member 1: </h4>

    <fieldset>
      <input placeholder="Member Description" type="text" name="ds1">
    </fieldset>

    <fieldset>
      <input placeholder="Member Name" type="text" name="nm1">
    </fieldset>

    <fieldset>
      <input placeholder="Member Company" type="text" name="cm1">
    </fieldset>

    <button name="btn_mm1" type="submit" id="contact-submit" data-submit="...Sending">EDIT</button>
  
    <h4> Member 2: </h4>

    <fieldset>
      <input placeholder="Member 2 Description" type="text" name="ds2">
    </fieldset>

    <fieldset>
      <input placeholder="Member 2 Name" type="text" name="nm2">
    </fieldset>

    <fieldset>
      <input placeholder="Member 2 Company" type="text" name="cm2">
    </fieldset>

    <button name="btn_mm2" type="submit" id="contact-submit" data-submit="...Sending">EDIT</button>
  
  </form>

<hr>


<form id="contact" action="action/sociallink.php" method="get">
    <h3>Social Media Link Editor Form: </h3>
    <fieldset>
      <input placeholder="Facebook" type="text" name="fb">
    </fieldset>

    <button name="btn_fb" type="submit" id="contact-submit" data-submit="...Sending">EDIT</button>

    <fieldset>
      <input placeholder="Google Plus" type="text" name="gg">
    </fieldset>

    <button name="btn_gg" type="submit" id="contact-submit" data-submit="...Sending">EDIT</button>

	<fieldset>
      <input placeholder="Instagram" type="text" name="ig">
    </fieldset>

    <button name="btn_ig" type="submit" id="contact-submit" data-submit="...Sending">EDIT</button>
  
  </form>


</div>

            <!-- /.container-fluid -->
            <footer class="footer text-center"> 2017 &copy; E-Gig Nepal Admin brought to you by egignepal.com </footer>
        </div>
        <!-- /#page-wrapper -->
    </div>
    <!-- /#wrapper -->
    <!-- jQuery -->
    <script src="../plugins/bower_components/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap Core JavaScript -->
    <script src="bootstrap/dist/js/bootstrap.min.js"></script>
    <!-- Menu Plugin JavaScript -->
    <script src="../plugins/bower_components/sidebar-nav/dist/sidebar-nav.min.js"></script>
    <!--slimscroll JavaScript -->
    <script src="js/jquery.slimscroll.js"></script>
    <!--Wave Effects -->
    <script src="js/waves.js"></script>
    <!--Counter js -->
    <script src="../plugins/bower_components/waypoints/lib/jquery.waypoints.js"></script>
    <script src="../plugins/bower_components/counterup/jquery.counterup.min.js"></script>
    <!--Morris JavaScript -->
    <script src="../plugins/bower_components/raphael/raphael-min.js"></script>
    <script src="../plugins/bower_components/morrisjs/morris.js"></script>
    <!-- Custom Theme JavaScript -->
    <script src="js/custom.min.js"></script>
    <script src="js/dashboard1.js"></script>
    <script src="../plugins/bower_components/toast-master/js/jquery.toast.js"></script>
    <script type="text/javascript">
    $(document).ready(function() {
        $.toast({
            heading: 'Welcome to E-GIG NEPAL admin',
            text: 'Use to edit website theme or other functions',
            position: 'top-right',
            loaderBg: '#ff6849',
            icon: 'info',
            hideAfter: 3500,
            stack: 6
        })
    });
    </script>
</body>

</html>
