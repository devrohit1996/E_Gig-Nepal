<?php
  session_start();
  include("../database/db_conn.php"); //a step back to access the file 'db_conn.php'

  $uname=$_GET['band'];

  $queryn=$conn->prepare("select * from band where band_name='$uname'");
  $queryn->execute();
  $result= $queryn->get_result();
    $row= $result->fetch_array(MYSQLI_ASSOC);

    $id= $row['band_id'];
    $name= $row['band_name'];   
    $genre= $row['genre'];
    $description= $row['description'];
    $usr=$row['added_by'];
    $photo= $row['photo'];

?>

<!DOCTYPE html>
<html lang="en">

  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title> <?php echo $name; ?> </title>

    <!-- Bootstrap core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="css/blog-post.css" rel="stylesheet">

  </head>

  <body>
   
    <!-- Page Content -->
    <div class="container">

      <div class="row">

        <!-- Post Content Column -->
        <div class="col-lg-8">

          <!-- Title -->
          <h1 class="mt-4"><?php echo $name; ?></h1>

          <!-- Author -->
          <p class="lead">
            by
            <a href="#"><?php echo $usr; ?></a>
          </p>

          <hr>

        

          <!-- Preview Image -->
          <?php
         echo "<img class='img-fluid rounded' src='../action/img/".$row['photo']."' alt='HTML5 Icon' style='height:300px; width:auto'>";
         ?>
          

          <hr>

          <!-- Post Content -->

          <h3> Description </h3>
          <p><?php echo $description; ?></p>

          <hr>

          <h3> Genre </h3>
          <p> <?php echo $genre; ?>


          <hr> 
    <!-- Bootstrap core JavaScript -->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/popper/popper.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.min.js"></script>

  </body>

</html>
